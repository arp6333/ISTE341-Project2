﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductService.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductService.Controllers
{
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private List<Product> products = new List<Product>();

        public ProductController()
        {
            CreateProducts();
        }

        private void CreateProducts()
        {
            products.Add(new Product(){Name = "Apples", Price = 3.99});
            products.Add(new Product(){Name = "Peaches", Price = 4.05});
            products.Add(new Product(){Name = "Pumpkin", Price = 13.99});
            products.Add(new Product(){Name = "Pie", Price = 8.00});
        }

        // GET: api/products
        [HttpGet]
        public IEnumerable<Product> GetNames()
        {
            return this.products;
        }

        // GET api/products/4
        [HttpGet("{price}", Name = "GetProduct")]
        public IActionResult GetPrice(long price)
        {
            Product product = products.Find(x => x.Price == price);
            if (product == null)
            {
                return NotFound();
            }
            return new ObjectResult(product);
        }

        // GET api/products/cheapest
        [HttpGet]
        public IActionResult GetCheapest()
        {
            double price = 10000.00;
            Product product = null;
            foreach (Product prod in products)
            {
                if (prod.Price < price)
                {
                    product = prod;
                    price = prod.Price;
                }
            }
            if (product == null)
            {
                return NotFound();
            }
            return new ObjectResult(product);
        }

        // GET api/products/costliest
        [HttpGet]
        public IActionResult GetCostliest()
        {
            double price = 0.00;
            Product product = null;
            foreach (Product prod in products)
            {
                if (prod.Price > price)
                {
                    product = prod;
                    price = prod.Price;
                }
            }
            if (product == null)
            {
                return NotFound();
            }
            return new ObjectResult(product);
        }
    }
}
