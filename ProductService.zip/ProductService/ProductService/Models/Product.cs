﻿using System;
namespace ProductService.Models
{
    public class Product
    {
        public double Price { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return "Price: " + Price + " Name: " + Name;
        }
        public Product()
        {
        }
    }
}
